function p = pell_generator(M)
  % This returns a vector of Pell numbers from 0 .. M.
  % Note that the return vector p has length M+1.
  
  % Initialize return vector
  p = zeros(M+1);
    
  % Get first two numbers manually.
  n = 0;
  pnm2 = 0;  % p0
  fprintf('n = %d, pn = %d\n', n, pnm2);
  p(1) = pnm2;

  n = n+1;
  pnm1 = 1;  % p1
  fprintf('n = %d, pn = %d\n', n, pnm1);
  p(2) = pnm1;

  % Get remaining Pell numbers in a loop.
  for n = 2:M
    pn = 2*pnm1 + pnm2;
    % fprintf('n = %d, pn = %d\n', n, pn);    
    p(n+1) = pn;
    
    % Move old values back.
    pnm2 = pnm1;
    pnm1 = pn;
  end
  
end

