function test_pell_generator()
  % This tests the Pell number generator by calling pell_generator
  % and then using various identities to verify the returned vector
  % of Pell numbers satisfies the identities.
  
  pass = 0;
  fail = 0;

  s = sqrt(2);
  tol = 1e-13; % testing tol

  % First get vector of 101 Pell numbers
  M = 100;
  p = pell_generator(M);
  
  % Verify each number satisfies p(n) = 2*p(n-1) + p(n-2) property.
  for n = 3:M+1;
    % Note that Binet numbers start from 0, so p(n) is actually
    % the n=1st Pell number.
    fprintf('n = %d ...', n)
    
    pn = p(n);
    pnm1 = p(n-1);
    pnm2 = p(n-2);
    fprintf('Testing recurrence property, pn = %d ... ', pn)
    if ( pn == (2*pnm1 + pnm2) )
      fprintf('Passed!\n')
      pass = pass+1;
    else
      fprintf('Failed!\n')
      fail = fail+1;
    end

    % Now try a Binet-type formula.  Since p(n) is the n+1 Pell number
    % we need to subtract 1 from n to get the right index.
    pnbinet = ( (1+s)^(n-1) - (1-s)^(n-1) )/(2*s);
    fprintf('Binet-type formula, pnbinet = %d ... ', pnbinet)    
    % I need to test against a reltol since the Pell numbers themselves
    % grow without bound for increasing n.
    diff = abs(pnbinet-pn)/pn;
    if (diff < tol)
      fprintf('Passed!  diff = %e\n', diff)
      pass = pass+1;
    else
      fprintf('Failed!  diff = %e\n', diff)    
      fail = fail+1;
    end

    % Separator
    fprintf('----------------------------------------\n')
    
  end
    
  fprintf('=================================\n')
  fprintf('At end of test, passed = %d, failed = %d\n', pass, fail)

end
