function make_plot()
  % This evaluates the polynomial (x-1)^7 over the interval
  % 1-delta .. 1+delta and makes a plot.  It does the eval in two ways:
  % 1.  Straight eval of (x-1)^7
  % 2.  Eval of expanded version
  % The plots are completely different due to loss of significance.
    
  delta = 1.2e-2;
  x = linspace(1-delta, 1+delta, 200);
  
  y1 = (x-1).^7;
  y2 = x.^7 - 7*x.^6 + 21*x.^5 - 35*x.^4 + 35*x.^3 - 21*x.^2 + 7*x - 1;
  
  plot(x,y1, 'r')
  hold on
  plot(x,y2, 'b')

  legend('Unexpanded poly', 'Expanded poly','location','northwest')
  xlabel('x')
  ylabel('p(x)')
  title('Seventh-degree polynomial')
  
end

