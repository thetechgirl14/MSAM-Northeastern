function test_tanh_contdfrac()
  % Test tanh against the Matlab built-in fcn.
    
  pass = 0;
  fail = 0;
  tol = 1e-7;
    
  for cnt = 1:20
    lim = pi/2; % 100;  % Convergence domain is much larger, but stick with pi/2.
    x = lim*(2*rand()-1);  % Generate random number in input domain
    ycomp = tanh_contdfrac(x);  % My computed value.
    ytrue = tanh(x);            % "True" (Matlab) value.
    fprintf('Input x = %e, computed tanh = %e ....', x, ycomp)
    diff = abs(ycomp - ytrue);
    if (diff < tol)
      % Success -- test passed.
      fprintf('... Test passed.  abs(ycomp - ytrue) = %e\n', diff)
      pass = pass + 1;
    else 
      % diff larger than tol -- test failed.      
      fprintf('... Test failed.  abs(ycomp - ytrue) = %e\n', diff)
      fail = fail + 1;
    end
  end

  fprintf('=====================================================\n')
  fprintf('At end, pass = %d, fail = %d\n', pass, fail)
  
end
