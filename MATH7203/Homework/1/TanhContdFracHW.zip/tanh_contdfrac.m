function yn = tanh_contdfrac(z)
  %----------------------------------------------
  % This problem involves writing a program computing tanh(z) using the
  % continued fraction expansion given in the DLMF:
  %
  % https://dlmf.nist.gov/4.39
  %
  % The expansion is
  %
  % tanh(z) = z/(1+z^2/(3+z^2/(5+z^2/ ... )))
  %
  % Using the notation presented in class, the coeffs are:
  %
  % b0 = 0
  %
  % a1 = z
  % b1 = 1
  %
  % a2 = z^2
  % b2 = 3
  %
  % a3 = z^2
  % b3 = 5
  %
  % In general, for j>1
  % aj = z^2
  % bj = 2*j-1
  % 
  % Now define:
  % Am1 = 1
  % Bm1 = 0
  % A0 = b0
  % B0 = 1
  % Aj = bj*Ajm1 - aj*Ajm2
  % Bj = bj*Bjm1 - aj Bjm2
  %
  % The A & B give the convergents:
  % fj = Aj/Bj
  %----------------------------------------------

% Initialize computation
  tol = 1e-10;
    
  b0 = 0;
  Ajm2 = 1;   % This is A(-1) in my notation
  Bjm2 = 0;
  Ajm1 = b0;  % This is A(0) in my notation
  Bjm1 = 1;
  
  % Do calc for j = 1 as special case
  aj = z;
  bj = 1;
  Aj = bj*Ajm1 + aj*Ajm2;
  Bj = bj*Bjm1 + aj*Bjm2;
  ynm1 = Aj/Bj;  % Convergent f1
  % Move back computed variables.
  Ajm2 = Ajm1;
  Bjm2 = Bjm1;
  Ajm1 = Aj;
  Bjm1 = Bj;

  % Now compute terms inside loop starting for j=2.
  z2 = z*z;  % Compute this here instead of doing it in the loop for efficiency.
  for j = 2:100
    aj = z2;
    bj = 2*j-1;
    Aj = bj*Ajm1 + aj*Ajm2;
    Bj = bj*Bjm1 + aj*Bjm2;
    yn = Aj/Bj;    % Convergent fj

    if (abs(yn - ynm1) < tol)
      % fprintf('Converged after %d iterations\n', j)
      return
    else
      % Didn't converge -- move vars back and loop again.
      ynm1 = yn;
      Ajm2 = Ajm1;
      Bjm2 = Bjm1;
      Ajm1 = Aj;
      Bjm1 = Bj;
    end
  end
  % If we get here it's because we didn't converge inside loop.
  error(['Input x = ' num2str(x) ' tanh_contdfrac did not converge!'])

end
