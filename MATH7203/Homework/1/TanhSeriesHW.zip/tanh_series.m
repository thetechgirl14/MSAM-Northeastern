function y = tanh_series(x)
  % This fcn implements tanh using a series summed using
  % Horner's rule.  The series expansion for tanh is
  % tanh(x) = x - x^3/3 + ... + 
  %          (2^(2*n)*(2^(2*n)-1)*B(2*n)/factorial(2*n)) * x^(2*n-1)
  % This is eq 4.33.3 in the DLMF.
  % Since computing the Bernoulli numbers is problematic, I
  % supply a function, mybernoulli, which returns the first few
  % Bernoulli numbers.
    
  
  % Restrict domain of input.
  if (abs(x) >= pi/2)
    error('Input to tanh_series must satisfy abs(x) < pi/2.')
  end
 
  % Start with term 1
  c = 1;      % Coefficient of first term
  p = x;      % Monomial of first term
  sn = c*p;   % Initialize the sum using this term.
  snm1 = sn;  % Initialize pushed-back sum
  
  n = 1;
  %fprintf('n = %d, c = %f\n', n, c);
  
  % Convergence tolerance.
  tol = 1e-6;
  
  % Now sum terms up to 34 power.
  for n = 2:17
    a = 2^(2*n);           % Convenience variable
    b = mybernoulli(2*n);  % Convenience variable
    c = a*(a-1)*b/factorial(2*n);  % Coefficient
    p = p*x*x;             % Power multiplied by x^2 with each loop iteration
    t = c*p;               % This term
    sn = sn + t;             % Add this term to sum
    %fprintf('n = %d, t = %e\n', n, t);

    % Now check for convergence
    if (abs(t) < tol)
      y = sn;
      return
    else
      snm1 = sn;
    end
    
  end

  % If we get here, it's because we did not converge.
  %error(['tanh_series did not converge in 34 iterations!'])
  y = sn;  % Just return my best guess and let the test sort it out.
  
end

