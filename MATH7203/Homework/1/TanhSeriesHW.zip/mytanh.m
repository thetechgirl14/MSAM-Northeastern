function y = mytanh(x)
  % This is the upper-level fcn computing tanh.  It checks
  % the input, and if the input is greater than pi/4, divides
  % the input into two pieces and computes tanh_series() on
  % each piece.  Then it uses an identity to assemble the
  % desired tanh value. Otherwise it computes tanh_series() the 
  % usual way.
    
  if (abs(x) > pi/2)
    error('mytanh input domain is restricted to -pi/2 ... pi/2')
  end
  
  if (abs(x) > pi/4)
    % Split input into two pieces and compute series separately.
    s = sign(x);
    x1 = s*pi/4;
    x2 = x-x1;
    y1 = tanh_series(x1);  % I could just replace this call with the
                           % value tanh(s*pi/4)
    y2 = tanh_series(x2);
    y = (y1+y2)/(1+y1*y2);
  else
    y = tanh_series(x);
  end
  return
end
