function test_mytanh()
  
  % Test mytanh against the Matlab built-in fcn.
    
  pass = 0;
  fail = 0;
  tol = 1e-6;
  
  fprintf('===============     Test mytanh     =================\n')
  
  for cnt = 1:20
    x = (pi/2)*(2*rand()-1);  % Generate random number in input domain -pi/2 to pi/2
    ycomp = mytanh(x);
    ytrue = tanh(x);
    fprintf('Input x = %e, computed tanh = %e ....', x, ycomp)
    diff = abs(ycomp - ytrue);
    if (diff < tol)
      % Success -- test passed.
      fprintf('... Test passed.  abs(ycomp - ytrue) = %e\n', diff)
      pass = pass + 1;
    else 
      % diff larger than tol -- test failed.      
      fprintf('... Test failed.  abs(ycomp - ytrue) = %e\n', diff)
      fail = fail + 1;
    end
    
  end
  fprintf('=====================================================\n')
  fprintf('At end, pass = %d, fail = %d\n', pass, fail)
  
end
