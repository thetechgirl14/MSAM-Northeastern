function y = tanh_continued_fraction(x)
    a0 = x;
    b0 = 1;
    a1 = x^2;
    b1 = 3;
    a2 = x^2;
    b2 = 5;
    for i = 3:1000
        a3 = x^2;
        b3 = 2*i + 1;
        a2 = b2*a3 + a2*b3;
        b2 = b2*b3 + a2*a3;
        a1 = b1*a2 + a1*b2;
        b1 = b1*b2 + a1*a2;
        a0 = b0*a1 + a0*b1;
        b0 = b0*b1 + a0*a1;
    end
    y = a0/b0;
end

